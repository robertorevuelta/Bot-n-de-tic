const hazAlgo = document.getElementById("elBoton");
 
hazAlgo.onclick = function () {
 document.body.style.backgroundColor = "rgb(249, 150, 37)";
}
const hazOtraCosa = document.getElementById("otroBoton");
 
hazOtraCosa.onclick = function () {
 document.body.style.backgroundColor = "rgb(93, 154, 246)";
}
 
const hazUnaTerceraCosa = document.getElementById("tercerBoton");
 
hazUnaTerceraCosa.onclick = function () {
 document.body.style.backgroundColor = "rgb(93, 246, 157)";
 }